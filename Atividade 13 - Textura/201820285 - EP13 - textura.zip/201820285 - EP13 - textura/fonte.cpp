#include <GL/glut.h>
#include <stdio.h>
#include "SOIL/SOIL.h"
#include "TextureClass.h"

GLfloat horzangle = -45.0, vertangle = 30.0, distance = -3.0;

GLuint idTextura = 1001;
GLuint textura1;

//FUN��O RETIRADA DO SITE DA PUC.RS PARA CARREGAMENTO DE TEXTURA UTILIZANDO SOIL.H E TEXTURECLASS.H *carrega imagem textura*
GLuint LoadTexture(const char* nomeTex)
{
    GLenum errorCode;
    GLuint IdTEX;
    // Habilita o uso de textura
    glEnable(GL_TEXTURE_2D);

    // Define a forma de armazenamento dos pixels na textura (1= alihamento por byte)
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

    // Gera um identificar para a textura
    glGenTextures(1, &IdTEX); //  vetor que guardas os n?meros das texturas
    errorCode = glGetError();
    
    glBindTexture(GL_TEXTURE_2D, IdTEX);

    // Carrega a imagem
    ImageClass Img;

    int r = Img.Load(nomeTex);

    int level = 0;
    int border = 0;

    // Envia a textura para OpenGL, usando o formato apropriado
    int formato;
    formato = GL_RGB;
    if (Img.Channels() == 4)
        formato = GL_RGBA;
    //if (Img.Channels() == 3)
    //   formato = GL_RGB;

    glTexImage2D(GL_TEXTURE_2D, level, formato,
        Img.SizeX(), Img.SizeY(),
        border, formato,
        GL_UNSIGNED_BYTE, Img.GetImagePtr());
    errorCode = glGetError();
   
    // Ajusta os filtros iniciais para a textura
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

    Img.Delete();

    return IdTEX;
}

void iniciaTextura() {
    textura1 = LoadTexture("ave.jpg");
}

//Display do programa
void Desenha(void) {
    //Configura��es iniciais para o programa rodar, alterando a perspectiva da vis�o, o modo de vis�o e a rota��o da nossa casinha

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    //Configura��es de rota��o e transla��o da casinha
    glTranslatef(0.0f, 0.0f, distance);
    glTranslatef(0.0f, 0.0f, -3.0f);
    glRotatef(vertangle, 1.0f, 0.0f, 0.0f);
    glRotatef(horzangle, 0.0f, 1.0f, 0.0f);

    glEnable(GL_DEPTH_TEST);

    //Habilitando a textura no nosso cubo
    glEnable(GL_TEXTURE_2D);
    glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
    glBindTexture(GL_TEXTURE_2D, textura1);

    //Fornece os valores para limpeza do buffer de cor no modo RGBA
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);


    //---------------- CONSTRU��O DO CUBO ----------------

    glBegin(GL_QUADS);
    // Front Face
    glNormal3f(0, 0, 1);
    glTexCoord2f(0.5f, 0.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);

    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);

    glTexCoord2f(1.0f, 0.5f);
    glVertex3f(1.0f, 1.0f, 1.0f);

    glTexCoord2f(0.5f, 0.5);
    glVertex3f(-1.0f, 1.0f, 1.0f);

    // Back Face
    glNormal3f(0, 0, -1);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);

    // Top Face
    glNormal3f(0, 1, 0);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-1.0f, 1.0f, 1.0f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);

    // Bottom Face
    glNormal3f(0, -1, 0);
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);

    // Right face
    glNormal3f(1, 0, 0);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, -1.0f);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(1.0f, 1.0f, 1.0f);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);

    // Left Face
    glNormal3f(-1, 0, 0);
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);
    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, 1.0f);
    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(-1.0f, 1.0f, -1.0f);
    glEnd();

    glFlush();
    glutSwapBuffers();
}

void AlteraTamanho(GLsizei width, GLsizei height) {
    glViewport(0, 0, width, height);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluPerspective(30.0, width / height, 1.0, 10.0);
}

//Fun��es de teclas do teclado
void LeftKey(void) {
    horzangle -= 10;
    Desenha();
}

void RightKey(void) {
    horzangle += 10;
    Desenha();
}

void UpKey(void) {
    vertangle -= 10;
    Desenha();
}

void DownKey(void) {
    vertangle += 10;
    Desenha();
}

void mouse(int button, int state, int x, int y) {
    if (button == GLUT_LEFT_BUTTON) {
        if (state == GLUT_UP) {
            LeftKey();
        }
    }

    if (button == GLUT_RIGHT_BUTTON) {
        if (state == GLUT_UP) {
            RightKey();
        }
    }
    glutPostRedisplay();
}

void teclado(int key, int x, int y) {
    switch (key) {
    case GLUT_KEY_UP:
        UpKey();
        break;
    case GLUT_KEY_DOWN:
        DownKey();
        break;
    case GLUT_KEY_LEFT:
        LeftKey();
        break;
    case GLUT_KEY_RIGHT:
        RightKey();
        break;
    }
    glutPostRedisplay();
}

int main(int argc, char* argv[]) {
    glutInit(&argc, argv);
    //Configura��es iniciais de display e janela
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_DEPTH | GLUT_RGBA);
    glutInitWindowSize(800, 800);
    glutInitWindowPosition(600, 150);
    glutCreateWindow("201820285 - Joao Almeida");

    //Caso seja necess�rio alterar o tamanho da janela em tempo real
    glutReshapeFunc(AlteraTamanho);
    //Fun��es do teclado e do mouse
    glutSpecialFunc(teclado);
    glutMouseFunc(mouse);
    //Fun��o desenha
    glutDisplayFunc(Desenha);
    glutMainLoop();
    return 0;
}
